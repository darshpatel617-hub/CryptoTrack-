const chartSeeds = {
  btc: {
    color: "#10b981",
    fill: "rgba(16, 185, 129, 0.12)",
    values: [38, 42, 41, 48, 52, 50, 57, 61, 64, 70, 68, 74],
  },
  eth: {
    color: "#2563eb",
    fill: "rgba(37, 99, 235, 0.11)",
    values: [46, 45, 47, 50, 49, 54, 58, 56, 61, 63, 65, 67],
  },
  ntc: {
    color: "#ef4444",
    fill: "rgba(239, 68, 68, 0.09)",
    values: [62, 58, 60, 55, 53, 51, 48, 46, 49, 45, 43, 44],
  },
  growth: {
    color: "#10b981",
    fill: "rgba(16, 185, 129, 0.1)",
    values: [42, 45, 44, 50, 55, 54, 59, 62, 66, 68, 72, 76, 74, 79, 84, 88],
  },
};

const charts = Array.from(document.querySelectorAll("canvas[data-chart]")).map((canvas) => {
  const seed = chartSeeds[canvas.dataset.chart];
  return {
    canvas,
    color: seed.color,
    fill: seed.fill,
    values: [...seed.values],
    targetValues: [...seed.values],
    nextTick: performance.now() + 900 + Math.random() * 700,
  };
});

function resizeCanvas(canvas) {
  const ratio = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  const width = Math.max(1, Math.floor(rect.width * ratio));
  const height = Math.max(1, Math.floor(rect.height * ratio));

  if (canvas.width !== width || canvas.height !== height) {
    canvas.width = width;
    canvas.height = height;
  }
}

function drawChart(chart, progress) {
  const { canvas, color, fill, values, targetValues } = chart;
  resizeCanvas(canvas);

  const ctx = canvas.getContext("2d");
  const width = canvas.width;
  const height = canvas.height;
  const padding = canvas.dataset.chart === "growth" ? 28 : 8;
  const points = values.map((value, index) => value + (targetValues[index] - value) * progress);
  const min = Math.min(...points) - 6;
  const max = Math.max(...points) + 6;
  const range = max - min || 1;
  const step = (width - padding * 2) / (points.length - 1);

  ctx.clearRect(0, 0, width, height);

  if (canvas.dataset.chart === "growth") {
    ctx.strokeStyle = "rgba(148, 163, 184, 0.18)";
    ctx.lineWidth = 1;
    for (let i = 1; i < 5; i += 1) {
      const y = (height / 5) * i;
      ctx.beginPath();
      ctx.moveTo(padding, y);
      ctx.lineTo(width - padding, y);
      ctx.stroke();
    }
  }

  const coordinates = points.map((point, index) => {
    const x = padding + index * step;
    const y = height - padding - ((point - min) / range) * (height - padding * 2);
    return { x, y };
  });

  ctx.beginPath();
  coordinates.forEach((point, index) => {
    if (index === 0) ctx.moveTo(point.x, point.y);
    else ctx.lineTo(point.x, point.y);
  });
  ctx.lineTo(width - padding, height - padding);
  ctx.lineTo(padding, height - padding);
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();

  const lineGradient = ctx.createLinearGradient(0, 0, width, 0);
  lineGradient.addColorStop(0, color);
  lineGradient.addColorStop(1, canvas.dataset.chart === "growth" ? "#2563eb" : color);
  ctx.strokeStyle = lineGradient;
  ctx.lineWidth = canvas.dataset.chart === "growth" ? 3 : 2.4;
  ctx.shadowColor = color;
  ctx.shadowBlur = 9;
  ctx.beginPath();
  coordinates.forEach((point, index) => {
    if (index === 0) ctx.moveTo(point.x, point.y);
    else ctx.lineTo(point.x, point.y);
  });
  ctx.stroke();
  ctx.shadowBlur = 0;

  const active = coordinates[coordinates.length - 1];
  const pulse = 1 + Math.sin(performance.now() / 220) * 0.22;
  ctx.fillStyle = "#ffffff";
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  ctx.shadowColor = color;
  ctx.shadowBlur = 14;
  ctx.beginPath();
  ctx.arc(active.x, active.y, (canvas.dataset.chart === "growth" ? 6 : 4.2) * pulse, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.shadowBlur = 0;
}

function updateTargets(chart) {
  const last = chart.targetValues[chart.targetValues.length - 1];
  const drift = (Math.random() - 0.44) * 8;
  const next = Math.max(18, Math.min(92, last + drift));
  chart.values = [...chart.targetValues];
  chart.targetValues = [...chart.targetValues.slice(1), next];
}

function animateCharts(now) {
  charts.forEach((chart) => {
    if (now > chart.nextTick) {
      updateTargets(chart);
      chart.startedAt = now;
      chart.nextTick = now + 1500 + Math.random() * 850;
    }
    const elapsed = now - (chart.startedAt || 0);
    const progress = Math.min(1, elapsed / 900);
    const smoothProgress = 1 - Math.pow(1 - progress, 3);
    drawChart(chart, smoothProgress);
  });

  if (charts.length) requestAnimationFrame(animateCharts);
}

if (charts.length) {
  requestAnimationFrame(animateCharts);
  window.addEventListener("resize", () => charts.forEach((chart) => drawChart(chart, 1)));
}

const ntcInput = document.querySelector("#ntcAmount");
const audInput = document.querySelector("#audAmount");
const exchangeForm = document.querySelector(".exchange-form");
const formNote = document.querySelector(".form-note");

if (ntcInput && audInput) {
  const formatter = new Intl.NumberFormat("en-AU", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  const updateAud = () => {
    const amount = Number.parseFloat(ntcInput.value) || 0;
    audInput.value = formatter.format(amount * 8.42);
  };

  ntcInput.addEventListener("input", updateAud);
  updateAud();
}

if (exchangeForm && formNote) {
  exchangeForm.addEventListener("submit", (event) => {
    event.preventDefault();
    formNote.textContent = "Exchange preview updated with the current NTC rate.";
  });
}

const chatWidget = document.querySelector(".chat-widget");
const chatToggle = document.querySelector(".chat-toggle");
const chatClose = document.querySelector(".chat-close");
const chatForm = document.querySelector(".chat-form");
const chatInput = document.querySelector(".chat-form input");
const chatMessages = document.querySelector(".chat-messages");

function setChatOpen(open) {
  if (!chatWidget || !chatToggle) return;
  chatWidget.classList.toggle("open", open);
  chatToggle.setAttribute("aria-expanded", String(open));
  if (open) setTimeout(() => chatInput?.focus(), 50);
}

chatToggle?.addEventListener("click", () => setChatOpen(!chatWidget.classList.contains("open")));
chatClose?.addEventListener("click", () => setChatOpen(false));

function appendMessage(text, type) {
  if (!chatMessages) return;
  const message = document.createElement("p");
  message.className = `message ${type}`;
  message.textContent = text;
  chatMessages.append(message);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

chatForm?.addEventListener("submit", (event) => {
  event.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;

  appendMessage(text, "user");
  chatInput.value = "";

  setTimeout(() => {
    appendMessage("The strongest current signal is portfolio growth stability, with NTC conversion staying near AUD 8.42.", "assistant");
  }, 420);
});

document.querySelector(".auth-form")?.addEventListener("submit", (event) => {
  event.preventDefault();
  window.location.href = "index.html";
});
